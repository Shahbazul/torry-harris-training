import java.util.Scanner;

public class ReadingValues<num> {
    public static void main(String []args) {
        int num;
        Scanner scan = new Scanner(System.in);
        num = scan.nextInt();
        System.out.println("number is " + num);
    }
}
