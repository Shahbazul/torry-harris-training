public class Demo1 {
    public static void main(String[] args) {
        System.out.println("Default values");
        byte b=0;
        short s=0;
        int i=0;
        long l=0;
        float f=0.0f;
        double d=0.0;
        boolean bl=false;
        char c='a';
        System.out.println("Byte is "+ b );
        System.out.println("Short is "+ s );
        System.out.println("Int is "+ i );
        System.out.println("Long is "+ l );
        System.out.println("Float is "+ f );
        System.out.println("Double is "+ d );
        System.out.println("Boolean is "+ bl );
        System.out.println("Character is "+ c );
    }
}
