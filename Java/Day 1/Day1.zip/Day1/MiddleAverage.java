import java.util.Scanner;

public class MiddleAverage {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        int n;
        n=scan.nextInt();
        int a[]=new int[n];
        float f[]=new float[n];
        for(int i=0;i<n;i++)
        {
            f[i]=scan.nextFloat();
        }
        float m=0;
        if(m%2==1)
        {

        }
    }
}
