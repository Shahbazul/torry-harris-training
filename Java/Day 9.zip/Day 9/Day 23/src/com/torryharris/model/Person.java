package com.torryharris.model;

import java.io.Serializable;

public class Person implements Serializable,Comparable<Person> {
    private String name;
    private int number;
    private String occupation;

    public Person() {
    }

    public Person(String name, int number, String occupation) {
        this.name = name;
        this.number = number;
        this.occupation = occupation;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getNumber() {
        return number;
    }

    public void setNumber(int number) {
        this.number = number;
    }

    public String getOccupation() {
        return occupation;
    }

    public void setOccupation(String occupation) {
        this.occupation = occupation;
    }

    @Override
    public String toString() {
        return "Person{" +
                "name='" + name + '\'' +
                ", number=" + number +
                ", occupation='" + occupation + '\'' +
                '}';
    }


    @Override
    public int compareTo(Person o) {
        return this.getNumber()-o.getNumber();
    }
}

