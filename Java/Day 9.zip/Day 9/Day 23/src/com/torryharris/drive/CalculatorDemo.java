package com.torryharris.drive;

import com.torryharris.testing.Calculator;

public class CalculatorDemo {
    public static void main(String[] args) {
        Calculator calculator = new Calculator();
        System.out.println("20+10= "+calculator.add(20,10));
        System.out.println("20-10= "+calculator.sub(20,10));
        System.out.println("20*10= "+calculator.mul(20,10));
        System.out.println("20/10= "+calculator.div(20,10));

    }
}
