package com.torryharris.drive;

import com.torryharris.testing.ChangeStringCase;

public class StringChangeCaseDemo {
    public static void main(String[] args) {
        ChangeStringCase stringCase = new ChangeStringCase();
        System.out.println(stringCase.toCapitalLetters("abcd"));
        System.out.println(stringCase.toSmallLetters("ABCD"));
    }
}
