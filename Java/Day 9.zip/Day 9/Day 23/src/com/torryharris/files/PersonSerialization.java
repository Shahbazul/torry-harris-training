package com.torryharris.files;

import com.torryharris.model.Employee;
import com.torryharris.model.Person;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

public class PersonSerialization {
    public static void main(String[] args) throws IOException {
        Person p1 = new Person("Kohli",101,"Manager");
        Person p2 = new Person("Dhoni",100,"SE");
        Person p3 = new Person("Zaheer",102,"SD");

        FileOutputStream fos = new FileOutputStream("people.txt");
        ObjectOutputStream personOutputStream = new ObjectOutputStream(fos);
        personOutputStream.writeObject(p1);
        personOutputStream.writeObject(p2);
        personOutputStream.writeObject(p3);
        personOutputStream.flush();
        personOutputStream.close();
        fos.close();
    }
}
