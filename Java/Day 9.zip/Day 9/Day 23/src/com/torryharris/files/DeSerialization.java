package com.torryharris.files;

import com.torryharris.model.Employee;

import java.io.EOFException;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.ArrayList;

public class DeSerialization {
    public static void main(String[] args)throws IOException,ClassNotFoundException {
        FileInputStream fis = new FileInputStream("employee.txt");
        ObjectInputStream employeeInputStream=  new ObjectInputStream(fis);
        ArrayList<Employee>employeeList=new ArrayList<>();
        Employee employee;
        System.out.println("Employee details are:");
        try {
            while (true) {
                employee = (Employee) employeeInputStream.readObject();
                employeeList.add(employee);
            }

        }catch(EOFException ex){

            }
            System.out.println("Employee details:");
            for (Employee emp : employeeList) {
                System.out.println(emp);
            }

    }
}
