package com.torryharris.files;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class FileAssignment {
    public static void main(String[] args)throws IOException{
        Scanner scan=new Scanner(System.in);
        System.out.println("Enter a number and name :");
        int number = scan.nextInt();
        String name=scan.next();
       // String data = new String(array);

        FileWriter writer = new FileWriter("output3.txt");
        for(int i=0;i<number;i++){
            writer.write(name);
            writer.write('\n');
        }
        writer.flush();
        writer.close();
    }
}

