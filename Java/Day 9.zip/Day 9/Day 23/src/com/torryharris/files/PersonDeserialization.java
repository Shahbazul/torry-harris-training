package com.torryharris.files;

import com.torryharris.model.Person;

import java.io.EOFException;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.ArrayList;

public class PersonDeserialization {
    public static void main(String[] args)throws IOException,ClassNotFoundException {
        FileInputStream fis = new FileInputStream("people.txt");
        ObjectInputStream personInputStream=  new ObjectInputStream(fis);
        ArrayList<Person> personList=new ArrayList<>();
        Person person;
        System.out.println("Person  details are:");
        try {
            while (true) {
                person = (Person) personInputStream.readObject();
                personList.add(person);
            }

        }catch(EOFException ex){

        }
        personList.sort(null);
        System.out.println("Person details:");
        for (Person ps : personList) {
            System.out.println(ps);
        }
    }
}
