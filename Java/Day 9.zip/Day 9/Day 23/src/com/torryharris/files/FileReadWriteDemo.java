package com.torryharris.files;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class FileReadWriteDemo {
    public static void main(String[] args)throws IOException {
        Scanner scan=new Scanner(System.in);
        System.out.println("Enter a number and name :");
        int number = scan.nextInt();
        String fileName=scan.next();

        File input = new File(fileName);
        FileReader reader = new FileReader(input);

        char []array=new char[(int)input.length()];
        reader.read(array);
        String data = new String(array);
        System.out.println(data);
        reader.close();

        for(int i=0;i<number;i++){
            System.out.println(data=fileName);
        }
        FileWriter writer = new FileWriter("output3.txt");
        writer.write(data);
        writer.flush();
        writer.close();
    }
}
