package com.torryharris.testing;

import java.util.Locale;

public class ChangeStringCase {

    public String toCapitalLetters(String str){
        return str.toUpperCase();
    }

    public String toSmallLetters(String str){
        return str.toLowerCase();
    }
}
