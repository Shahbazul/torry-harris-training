package com.torryharris.testing;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class ChangeStringCaseTest {

    ChangeStringCase stringCase=new ChangeStringCase();
    @Before
    public void setUp() throws Exception {
        System.out.println("Before test case");
        stringCase=new ChangeStringCase();
    }

    @After
    public void tearDown() throws Exception {
        System.out.println("End test case");
    }

    @Test
    public void toCapitalLetters() {
        Assert.assertEquals("ABCD",stringCase.toCapitalLetters("abcd"));
    }

    @Test
    public void toSmallLetters() {
        Assert.assertEquals("abcd",stringCase.toSmallLetters("ABCD"));
    }
}