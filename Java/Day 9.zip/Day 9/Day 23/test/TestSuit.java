import com.torryharris.testing.ChangeStringCase;
import com.torryharris.testing.ChangeStringCaseTest;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)

@Suite.SuiteClasses({
        CalculatorTest.class,
        ChangeStringCaseTest.class
})
public class TestSuit {

}
